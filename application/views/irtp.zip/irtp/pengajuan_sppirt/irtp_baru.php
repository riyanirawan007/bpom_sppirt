
<style type="text/css">
	.clearfix input {
		width: 600px;
	}
	.clearfix textarea {
		margin: 0px; 
		width: 601px; 
		height: 55px;
	}
	.form-group label {
		text-align: right;
	}
</style>

	
	
<script type="text/javascript">


function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	return true;
}
$(document).ready(function() {
	//nama perusahaan
	
    // for (var selector in config) {
    //   $(selector).chosen(config[selector]);
    // }
	$(document).on('click', '.btn-delete', function(e){
		var curr = $(this);
		curr.parents('.data-strip').remove();
	});
	
	$(document).on('click', '.btn-add', function(e){
		var DOM = $(this).parents('.clearfix');
		var curr = $(this);
		var temp = '<div class="row data-strip" style="margin-top : 0px"> \
						<div class="col-sm-4"> \
							<select class="select2" data-placeholder="Masukan Komposisi Tambahan" style="max-width : 250px;" name="komposisi_tambah[]"> \
							<?php foreach($js_komp_tmbh as $data): ?> \
								<option value="<?=$data->no_urut_btp?>"><?=addslashes($data->nama_bahan_tambahan_pangan)?></option> \
							<?php endforeach ?>	\
							</select> \
						</div> \
                        <div class="col-sm-2"> \
							<input style="max-width: 100px;" type="text" class="form-control" name="berat_bersih_tambahan[]" placeholder="Berat Bersih" data-validation="required"/> \
						</div> \
						<div class="col-sm-2">\
							<select style="max-width: 120px;" class="form-control">\
								<option> ukuran</option>\
								<option>kg</option>\
							</select>\
					    </div>\
                        <div class="col-sm-2"> \
							<div class="btn btn-sm btn-primary btn-add" >Add</div> \
						</div> \
					</div><br>';
		DOM.append(temp);	
		DOM.find('select2').trigger('select2:updated').select2({'width' : '100%'});
		
		curr.html('Delete').removeClass('btn-primary btn-add').addClass('btn-danger btn-delete');
	});
	
	$('#pemilik_usaha').change(function(){
		var value = $(this).val();
		var penanggung = $('#penanggung_jawab');
		var telepon = $('#telepon_irtp');
		var alamat = $('#alamat_irtp');
		
		$.ajax({
			url	: '<?=base_url()?>irtp/get_perusahaan_raw',
			dataType : 'json',
			type : 'POST',
			data : 'kode=' + value,
			success: function(html){
				$.each(html, function(key, value){
					penanggung.val(value.nama_penanggung_jawab);
					penanggung.removeAttr('readonly');
					telepon.val(value.nomor_telefon_irtp);
					alamat.val(value.alamat_irtp);
				});
			},error: function(e){
				
			}
		});	
	});
	
	$('#provinsi').change(function(){
		var provinsi = $(this).val();
		var kabupaten = $('#kabupaten').parents('.dropdown');
		jQuery.ajax({
			url	:	'<?=base_url()?>irtp/get_kabupaten'	,
			type : 'POST',
			dataType : 'json',
			data	: 'provinsi=' + provinsi,
			success: function(html){
				var temp;
				temp = "<select id='kabupaten' class='select2'>";
				$.each(html, function(val, key){
					temp += "<option value='" + key.no_kabupaten + "'>" + key.nm_kabupaten + "</option>";
				});				
				temp += "</select>";
				console.log(temp);
				kabupaten.empty().append(temp);
				kabupaten.find('#kabupaten').trigger('chosen:updated').chosen({'width' : '100%'});
				
			},error: function(e){
				console.log(e);
			}
		});	
	});

	$('#grup_jenis_pangan').change(function(){
		var grup_jenis_pangan = $(this).val();
		var jenis_pangan = $('#jenis_pangan').parents('.dropdown');
		jQuery.ajax({
			url	:	'<?=base_url()?>irtp/get_jenis_pangan'	,
			type : 'POST',
			dataType : 'json',
			data	: 'grup_jenis_pangan=' + grup_jenis_pangan,
			success: function(html){
				var temp;
				temp = "<div class='col-xs-12 col-sm-9'><div class='clearfix'><select class='select2' name='jenis_pangan' id='jenis_pangan'><option value=''>- Pilih Nama Jenis Pangan -</option>";
				$.each(html, function(val, key){
					temp += "<option value='" + key.id_urut_jenis_pangan + "'>" + key.jenis_pangan + "</option>";
				});		
				temp += "<option value='-'>Lainnya</option></select></div></div>";		
				console.log(temp);
				jenis_pangan.empty().append(temp);
				jenis_pangan.find('#jenis_pangan').trigger('select2:updated').select2({'width' : '100%'});

				jQuery.ajax({
					url	:	'<?=base_url()?>irtp/get_grup_jenis_pangan'	,
					type : 'POST',
					dataType : 'json',
					data	: 'grup_jenis_pangan=' + grup_jenis_pangan,
					success: function(html){
						$('#label_jenis_pangan').html('Nama Jenis Pangan ('+html+')');
					},error: function(e){
							console.log(e);
						}
					});	
			},error: function(e){
				console.log(e);
			}
		});	
	});
	
	
	$('.datetimepicker').datetimepicker();

	var perusahaan = $("#pil_perusahaan").val();
	
	$(".ui-autocomplete").click(function(){
		//$("#alamat_perusahaan").val('tes');
		var perusahaan = $("#pil_perusahaan").val();
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_alamat_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#alamat_perusahaan").val(data);
			}
		});
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_telp_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#telp_perusahaan").val(data);
			}
		}); 
	});
	
	$('#proses_produksi').change(function(){
		var value = $(this).val();
		if(value=='11'){
			$('#box_proses_produksi').show();
			$('#proses_produksi_lain').val('');
			$('#proses_produksi_lain').attr("data-validation","required");
			
		} else {
			$('#box_proses_produksi').hide();
			$('#proses_produksi_lain').val('');
			$('#proses_produksi_lain').removeAttr("data-validation");
		}
	});
	
	$('#jenis_kemasan').change(function(){
		var value = $(this).val();
		if(value=='6'){
			$('#box_jenis_kemasan').show();
			$('#jenis_kemasan_lain').val('');
			$('#jenis_kemasan_lain').attr("data-validation","required");
			
		} else {
			$('#box_jenis_kemasan').hide();
			$('#jenis_kemasan_lain').val('');
			$('#jenis_kemasan_lain').removeAttr("data-validation");
		}
	});
	
});

$(document).delegate("#jenis_pangan", "change", function() {
	var value = $(this).val();
	if(value=='-'){
		$('#box_jenis_pangan').show();
		$('#jenis_pangan_lain').val('');
		$('#jenis_pangan_lain').attr("data-validation","required");
		
	} else {
		$('#box_jenis_pangan').hide();
		$('#jenis_pangan_lain').val('');
		$('#jenis_pangan_lain').removeAttr("data-validation");
	}
});

function cek_permohonan(){
	var masa_simpan = $('#masa_simpan').val();
	if(masa_simpan.indexOf('hari') > -1 || masa_simpan.indexOf('Hari') > -1){
		var r = confirm("Apakah Anda yakin?");
		if (r == true) {
			return true;
		} else {
			return false;
		}
	} else {
		alert('Masa simpan (kedaluwarsa) harus dalam format Hari, contoh : 90 hari');
		return false;
	}
}
</script>	

<!--<link href="<?php echo base_url();?>css/bpom.css" rel="stylesheet">	-->
<link href="<?php echo base_url();?>css/chosen/chosen.min.css" rel="stylesheet">	
<script type="text/javascript" src="<?=base_url()?>js/chosen/chosen.jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/chosen/prism.js"></script>

<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
	try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
</script>

<ul class="breadcrumb">
	<li>
		<i class="ace-icon fa fa-home home-icon"></i>
		<a href="dashboard">Dashboard</a>
	</li>
	<li class="active">Input Data Jenis IRTP Baru</li>
</ul>

</div>

<div class="page-content">

<!-- <div class="page-header">
		<h1>
			Dashboard
			<small>
				<i class="ace-icon fa fa-angle-double-right"></i>
				Input Data Jenis IRTP Baru
			</small>
		</h1>
	</div> -->

<div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
					<div class="row">
						<div class="col-xs-6">
							<h3 class="smaller lighter blue">Input Data Jenis IRTP Baru</h3>
						</div>
						<!-- <dir class="col-xs-6" style="text-align: right;">							
							<a href="<?php echo base_url().'role_menu/add';?>" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-edit bigger-120 blue"></i>
								Tambah Role Menu
							</a>
						</dir> -->
					</div>
					<div class="widget-box">
									<div class="widget-header widget-header-blue widget-header-flat">
										<h4 class="widget-title lighter">Status Pengajuan</h4>

										<!-- <div class="widget-toolbar">
											<label>
												<small class="green">
													<b>Validation</b>
												</small>

												<input id="skip-validation" type="checkbox" class="ace ace-switch ace-switch-4" />
												<span class="lbl middle"></span>
											</label>
										</div> -->
									</div>

									<div class="widget-body">
										<div class="widget-main">
											<div id="fuelux-wizard-container">
												<div>
													<ul class="steps">
														<li data-step="1" class="active">
															<span class="step">1</span>
															<span class="title">Informasi Kepemilikan</span>
														</li>

														<li data-step="2">
															<span class="step">2</span>
															<span class="title">Informasi Produk Pangan</span>
														</li>

														<li data-step="3">
															<span class="step">3</span>
															<span class="title">Finish</span>
														</li>

													</ul>
												</div>

												<hr />

										<div class="step-content pos-rel">
													<div class="step-pane active" data-step="1">
													
																	<?= @$this->session->flashdata('status'); ?>
																	<?= @$this->session->flashdata('error'); ?>	
																	<?= @$this->session->flashdata('message'); ?>	
																	<?=form_open_multipart('irtp/irtp_baru', array('class' => 'form-horizontal', 'id' => 'validation-form', 'method' => 'get'))?>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama IRTP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" id="nama_perusahaan" name="nama_perusahaan" placeholder="Masukkan Nama IRTP" data-validation="required"/>
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama IRTP, Contoh : CV. Aroma</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">No NIK Pemilik</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" id="no_nik" name="no_nik" placeholder="Masukkan No NIK" data-validation="number" data-validation-allowing="range[0;99999]" onkeypress="return isNumberKey(event)" maxlength="16" />
																				<p class="col-xs-12 col-sm-9 help-block">No NIK Pemilik IRTP (maksimal 16 digit angka)</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Penanggung Jawab IRTP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input name="penanggung_jawab" type="text" class="col-xs-12 col-sm-9" id="penanggung_jawab" placeholder="Pilih Nama Pemilik IRTP terlebih dahulu" data-validation="required" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Penanggung Jawab IRTP, Contoh : Hasan Sadikin S.Pd</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Alamat IRTP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<textarea style="margin: 0px; width: 601px; height: 55px;" class="input-xlarge" id="alamat_irtp" name="alamat_irtp" data-validation="required" placeholder="Masukan Alamat Lengkap IRTP" ></textarea>
																				<p class="col-xs-12 col-sm-9 help-block">		
																				Alamat IRTP akan terisi otomatis setelah memilih Nama Pemilik IRTP, Contoh : Jl. Margonda Raya No. 123, Pondok Cina</p>
																			</div>
																		</div>
																	</div>

																	<!-- <div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Kecamatan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" id="" placeholder="Masukkan Kecamatan" />
																				
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Kelurahan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" id="" placeholder="Masukkan Kelurahan" />
																				
																			</div>
																		</div>
																	</div> -->
																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Provinsi</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<select class="select2 " name="nama_propinsi" id="provinsi" data-validation="required">
													                        	<?php echo $filter; ?>
																				<?php foreach($data_select as $data): ?>			
																				<option value="<?=$data->no_kode_propinsi?>"><?=$data->nama_propinsi?></option>
																				<?php endforeach ?>				
																			</select>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Provinsi sesuai dengan list rujukan.</p>
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Kabupaten/Kota</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<select class="select2 " name="nama_kabupaten" id="kabupaten" data-validation="required">
																				<?php echo $filter_kab; ?>
																			</select>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Kabupaten/Kota sesuai dengan list rujukan.</p>
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Kode Pos</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" placeholder="Masukan Kode Pos IRTP" name="pos_irtp" data-validation="number" data-validation-allowing="range[0;99999]" onkeypress="return isNumberKey(event)" maxlength="5" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Kode Pos IRTP (maksimal 5 digit angka), Contoh : 14211, Jika Kode Pos belum diketahui isi dengan 0</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nomor Telepon IRTP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input name="telepon_irtp" type="text" class="col-xs-12 col-sm-9" data-validation="number" data-validation-allowing="range[0;99999999999999]" id="nomor_telepon_irtp" placeholder="Masukan Nomor Telepon IRTP" onkeypress="return isNumberKey(event)" maxlength="14" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nomor Telepon IRTP (maksimal 14 digit angka), Contoh : 02112345678901</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Upload Izin Usaha</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="file" name="file_pdf"><p class="col-xs-12 col-sm-9 help-block">Scan format PDF/JPG maksimal berukuran 2 Mb</p>
																			</div>
																		</div>
																	</div>
																	<!--<button type="submit" class="btn btn-primary col-md-12 col-sm-12"><b>Kirim &raquo;</b></button>-->
																	<?=form_close()?>
													</div>

													<div class="step-pane" data-step="2">
														<?= @$this->session->flashdata('status'); ?>
														<?= @$this->session->flashdata('error'); ?>	
														<?= @$this->session->flashdata('message'); ?>	
														<?=form_open_multipart('irtp/set_data_irtp_perpanjangan', array('class' => 'form-horizontal', 'id' => 'validation-form', 'method' => 'get'))?>
														<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Kategori Jenis Pangan</label>

																	<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																			   
																				<select class="select2" name="grup_jenis_pangan" id="grup_jenis_pangan" >
																				<option value="">- Pilih Kategori Jenis Pangan -</option>
																				<?php foreach($js_grup_pangan as $values): ?>
																						<option value="<?=$values->kode_grup_jenis_pangan?>"><?=$values->kode_grup_jenis_pangan." ".$values->nama_grup_jenis_pangan?></option>
																					</optgroup>
																				<?php endforeach ?>
																				</select>	
																				
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Kategori Jenis Pangan sesuai dengan list rujukan, Contoh : Hasil Olahan Daging Kering</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Jenis Pangan</label>

																	<div class="col-xs-12 col-sm-9">
																			
																			    <div class="dropdown">
																				<select class="select2" name="jenis_pangan" id="jenis_pangan" >
																					<option value="">- Pilih Nama Jenis Pangan -</option>	
																				</select>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Nama Jenis Pangan sesuai dengan list rujukan, Contoh : Bihun</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Jenis Pangan (Lainnya)</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" name="jenis_pangan_lain" class="col-xs-12 col-sm-9"id="jenis_pangan_lain" placeholder="Isi Jenis Pangan Lain"/>
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Jenis Pangan Lainnya, Contoh : Ganyong</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Produk Pangan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<textarea style="margin: 0px; width: 601px; height: 55px;" class="input-xlarge" name="deskripsi_pangan"id="deskripsi_pangan"  placeholder="Masukan Nama Produk Pangan" /></textarea>
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Produk Pangan Contoh : Krupuk </p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Dagang</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="nama_dagang" id="nama_dagang" placeholder="Masukan Nama Dagang" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Dagang, Contoh : Kripik Maicih</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Jenis Kemasan</label>
																	<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<select class="select2" name="jenis_kemasan" id="jenis_kemasan" >
																				<option value="">- Pilih Jenis Kemasan -</option>
																					<?php foreach($js_kemasan as $data): ?>
																						<option value="<?=$data->kode_kemasan?>"><?=$data->jenis_kemasan?></option>
																					<?php endforeach ?>				
																				</select>	
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Jenis Kemasan yang kontak langsung dengan pangan sesuai dengan list rujukan, Contoh : Plastik</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Jenis Kemasan (Lainnya)</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="jenis_kemasan_lain" id="jenis_kemasan_lain" placeholder="Isi Jenis Kemasan"/>
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Jenis Kemasan Lainnya, Contoh : Karung</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Berat Bersih / Isi Bersih</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="berat_bersih" id="berat_bersih"  placeholder="Masukan Berat Bersih / Isi Bersih" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Dagang, Contoh : Kripik Maicih</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Komposisi Bahan Utama</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<textarea style="margin: 0px; width: 601px; height: 55px;" class="input-xlarge" name="komposisi_utama" id="komposisi_utama"  placeholder="Masukan Komposisi Bahan Utama"  /></textarea>
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Komposisi Bahan Utama (diisi menurut komposisi yang terbesar), Contoh : 1. Tepung Terigu, 2. Garam</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Komposisi Bahan Tambahan Pangan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<div class="row data-strip">
																					<div class="col-sm-4">
																						<select style="max-width: 250px;" class="select2" name="komposisi_tambah[]" id="proses_produksi"data-placeholder="Masukan Komposisi Tambahan">
																				<?php foreach($js_komp_tmbh as $data): ?>
												                                    <option value="<?=$data->no_urut_btp?>"><?php echo $data->nama_bahan_tambahan_pangan;?></option>
												                                <?php endforeach ?>				
												                                </select>
																					</div>
																					<div class="col-sm-2">
																						<input type="text" class="form-control" style="max-width: 100px;" name="berat_bersih_tambahan[]" placeholder="Berat Bersih" />
																					</div>

																					<div class="col-sm-2">
																						<select style="max-width: 120px;" class="form-control">
																							<option> ukuran</option>
																							<option>kg</option>
																						</select>
																					</div>
																					<div class="col-sm-2">
																						<div class="btn-add btn btn-sm btn-primary" style="width:65px">Add</div>
																					</div>
												                                </div>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Komposisi Bahan Tambahan Pangan sesuai dengan list rujukan dan isilah berat bersih lengkap dengan satuannya, Contoh : Kalsium alginat (Calcium alginate) | 20 miligram/kg bahan, bila tidak menggunakan bahan tambahan, pilih "Tanpa Bahan Tambahan Pangan" kemudian diisi angka 0</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Proses Produksi</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<select class="select2" name="proses_produksi" id="proses_produksi" >
																				<option value="">- Pilih Proses Produksi -</option>
																					<?php foreach($js_tek_olah as $data): ?>
																						<option value="<?=$data->kode_tek_olah?>"><?=$data->kode_tek_olah." - ".$data->tek_olah?></option>
																					<?php endforeach ?>				
																				</select>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Proses Produksi sesuai dengan list rujukan, Contoh : Menggoreng</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Proses Produksi (Lainnya)</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="proses_produksi_lain" id="proses_produksi_lain" placeholder="Isi Proses Produksi"  />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Proses Produksi Lainnya, Contoh : Pengasapan</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Informasi Masa Simpan (Kedaluwarsa)</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="masa_simpan"  id="masa_simpan" placeholder="Masukan Informasi Masa Simpan (Kedaluwarsa)" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Informasi Masa Simpan (Kedaluwarsa) <b>harus dalam satuan Hari</b>, Contoh : 90 hari</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Informasi Kode Produksi</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="kode_produksi"  id="info_kode_produksi" placeholder="Masukan Informasi Kode Produksi" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Informasi Kode Produksi dengan lengkap, Contoh : A.01.12.17 menunjukkan A = Shift Pagi; 01 = Tanggal 1; 12 = bulan Desember; 17 = tahun 2017. </p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Tanggal Pengajuan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="input-group col-xs-12 col-sm-9">
																				<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" name="tanggal_pengajuan" placeholder="Pilih Tanggal Pengajuan"/>
																				<span class="input-group-addon">
																					<i class="fa fa-calendar bigger-110"></i>
																				</span>
																				</div>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Tanggal Pengajuan, Contoh : 2014-08-04</p>
																			
																		</div>
																	</div>

																	

														<?=form_close()?>
													</div>

													<div class="step-pane" data-step="3">
																<div class="center">
																	<h3 class="green">Data Anda Sudah Terisi Semua.</h3>
																	<b>Pastikan data inputan yang Anda masukkan sudah benar. Silahkan lakukan pengecekan jika terdapat kesalahan input. <br>Tekan tombol Selesai di bawah ini untuk mengakhiri proses inputan dan menyimpan data inputan.</b>
																</div>
													</div>
												</div>
											</div>

											<hr />
											<div class="wizard-actions">
												<button class="btn btn-prev">
													<i class="ace-icon fa fa-arrow-left"></i>
													Sebelumnya
												</button>

												<button class="btn btn-warning btn-next" data-last="Selesai">
													Selanjutnya
													<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
												</button>
											</div>
										</div>
	<!--KONTENNYA DISINI-->
	
    
</div>
					
					</div>
			</div>
		</div>
</div>
</div>
								

