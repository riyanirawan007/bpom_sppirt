<script>
$(document).ready(function() {
	$('#provinsi').change(function(){
			var provinsi = $(this).val();
			var kabupaten = $('#kabupaten').parents('.dropdown');
			jQuery.ajax({
				url	:	'<?=base_url()?>irtp/get_kabupaten'	,
				type : 'POST',
				dataType : 'json',
				data	: 'provinsi=' + provinsi,
				success: function(html){
					var temp;
					$.each(html, function(val, key){
						temp += "<option value='" + key.id_urut_kabupaten + "'>" + key.no_kabupaten + ". " + key.nm_kabupaten + "</option>";
					});				
					
					console.log($('#kabupaten').html(temp));
					$('#kabupaten').trigger('liszt:updated').chosen();
					
				},error: function(e){
					console.log(e);
				}
			});	
		});
});
</script>

<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
	try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
</script>

<ul class="breadcrumb">
	<li>
		<i class="ace-icon fa fa-home home-icon"></i>
		<a href="dashboard">Dashboard</a>
	</li>
	<li class="active">Data List Pencabutan SPP-IRT</li>
</ul>

</div>

<div class="page-content">

<!-- <div class="page-header">
		<h1>
			Dashboard
			<small>
				<i class="ace-icon fa fa-angle-double-right"></i>
				Data List Pencabutan SPP-IRT
			</small>
		</h1>
	</div> -->

<div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
					<div class="row">
						<div class="col-xs-6">
							<h3 class="smaller lighter blue">Tabel Data List Pencabutan SPP-IRT</h3>
						</div>
						<!-- <dir class="col-xs-6" style="text-align: right;">							
							<a href="<?php echo base_url().'role_menu/add';?>" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-edit bigger-120 blue"></i>
								Tambah Role Menu
							</a>
						</dir> -->
					</div>

					<div class="table-header">
						Hasil untuk "Data List Pencabutan SPP-IRT"
					</div>

					<div class="table-responsive">
						<?php echo $table; ?>
					</div>
				</div>
			</div>
		</div>
</div>

</div>

<div class="col-sm-12">
										<div class="row">
											<div class="col-xs-12">
												<div class="widget-box">
													<div class="widget-header widget-header-flat">
														<h4 class="widget-title smaller">Information</h4>

														
													</div>

													<div class="widget-body">
														<div class="widget-main">
															
															<dl id="dt-list-1">
																<dd><?php echo "Jumlah SPP-IRT yang dicabut : <b>".$jumlah_pencabutan_irtp. "</b><br>";?></dd>
																<dd><?php echo "Jumlah SPP-IRT yang dicabut berdasarkan Alasan Pencabutan : <!--<b>".count($jml_alasan). "</b>--><br>";
																	echo "<ul class='list-unstyled spaced2'>";
																		foreach($jml_alasan as $data){
																			$nm_alasan = ($data->alasan_pencabutan!='-')?$data->alasan_pencabutan:"(Lainnya)";
																			echo "<li><i class='ace-icon fa fa-circle green'></i>".$nm_alasan." sebanyak <b>". $data->count_alasan ." SPP-IRT</b></li>";
																		}
																	echo "</ul>";
																	?></dd>
																<dd><?php echo "Jumlah SPP-IRT yang dicabut berdasarkan Jenis Pangan : <!--<b>".count($jml_pangan). "</b>--><br>";
																	echo "<ul class='list-unstyled spaced2'>";
																		foreach($jml_pangan as $data){
																			echo "<li><i class='ace-icon fa fa-circle green'></i>".$data->jenis_pangan ." sebanyak <b>". $data->count_jenis ." SPP-IRT</b></li>";
																		}
																	echo "</ul>";
																	?></dd>
															</dl>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>

