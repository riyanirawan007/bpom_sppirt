<script>
$(document).ready(function() {
	$('#provinsi').change(function(){
			var provinsi = $(this).val();
			var kabupaten = $('#kabupaten').parents('.dropdown');
			jQuery.ajax({
				url	:	'<?=base_url()?>irtp/get_kabupaten'	,
				type : 'POST',
				dataType : 'json',
				data	: 'provinsi=' + provinsi,
				success: function(html){
					var temp;
					$.each(html, function(val, key){
						temp += "<option value='" + key.id_urut_kabupaten + "'>" + key.no_kabupaten + ". " + key.nm_kabupaten + "</option>";
					});				
					
					console.log($('#kabupaten').html(temp));
					$('#kabupaten').trigger('liszt:updated').chosen();
					
				},error: function(e){
					console.log(e);
				}
			});	
		});
});
</script>



<div class="page-content">

<div class="page-header">
		<h1>
			Dashboard
			<small>
				<i class="ace-icon fa fa-angle-double-right"></i>
				Data List Permohonan
			</small>
		</h1>
	</div>

<div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
					<div class="row">
						<div class="col-xs-6">
							<h3 class="smaller lighter blue">Tabel Data List Permohonan</h3>
						</div>
						<!-- <dir class="col-xs-6" style="text-align: right;">							
							<a href="<?php echo base_url().'role_menu/add';?>" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-edit bigger-120 blue"></i>
								Tambah Role Menu
							</a>
						</dir> -->
					</div>

					<div class="table-header">
						Hasil untuk "Data List Permohonan"
					</div>

					<div class="table-responsive">
						<?php echo $table; ?>
					</div>
				</div>
			</div>
		</div>
</div>

</div>

									<div class="col-sm-12">
										<div class="row">
											<div class="col-xs-12">
												<div class="widget-box">
													<div class="widget-header widget-header-flat">
														<h4 class="widget-title smaller">Information</h4>

														
													</div>

													<div class="widget-body">
														<div class="widget-main">
															
															<dl id="dt-list-1">
																<dd><?php echo "Jumlah IRTP Yang Mendaftar : <b>".$jumlah_irtp. " IRTP</b><br>";?></dd>
																<dd><?php echo "Jumlah IRTP Berdasarkan Jenis Pangan : <!--<b>".count($jml_pangan). " IRTP</b>--><br>"; 
																echo "<ul class='list-unstyled spaced2'>";
																foreach($jml_pangan as $data){
																	echo "<li><i class='ace-icon fa fa-circle green'></i>".$data->jenis_pangan ." sebanyak <b>". $data->count_jenis ." IRTP</b></li>";
																}
															echo "</ul>";
																?></dd>
																<dd><?php echo "Jumlah IRTP Berdasarkan Jenis Kemasan : <!--<b>".count($jml_kemasan). " IRTP</b>--><br>";
																	echo "<ul class='list-unstyled spaced2'>";
																		foreach($jml_kemasan as $data){
																			echo "<li><i class='ace-icon fa fa-circle green'></i>".$data->jenis_kemasan ." sebanyak <b>". $data->count_kemasan ." IRTP</b></li>";
																		}
																	echo "</ul>";
																	?>	</dd>
																
																<dd><?php echo "Jumlah IRTP Berdasarkan Komposisi : <!--<b>".count($jml_komposisi). " IRTP</b>--><br>";
																	echo "<ul class='list-unstyled spaced2'>";
																		foreach($jml_komposisi as $data){
																			echo "<li><i class='ace-icon fa fa-circle green'></i>".$data->nama_bahan_tambahan_pangan ." sebanyak <b>". $data->jml_komposisi_perusahaan ." IRTP</b></li>";
																		}
																	echo "</ul>";
																	?></dd>
															</dl>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
	


<script src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1','packages':['corechart']}]}" language='javascript1.4'></script>
<!-- <script>
jQuery(document).ready(function(){
	jQuery('.datetimepicker').datetimepicker();
	
	var dataPangan = <?php
		// echo "[['Jenis Pangan', 'Jumlah Jenis Pangan'],";
		// $i = 0;
		// $chart = "";
		// foreach($jml_pangan as $data){
		// 	$chart .= "['".$data->jenis_pangan."', ".$data->count_jenis."], ";
		// 	$i++;
		// }
		// echo $chart;
		// echo "]";
	?>;
	var dataKemasan = <?php
		// echo "[['Jenis Kemasan', 'Jumlah Kemasan'],";
		// $i = 0;
		// $chart = "";
		// foreach($jml_kemasan as $data){
		// 	$chart .= "['".$data->jenis_kemasan."', ".$data->count_kemasan."], ";
		// 	$i++;
		// }
		// echo $chart;
		// echo "]";
	?>;
	var obj = jQuery('.dom');
	var data = new Array();
	
	data = { 0 : dataPangan, 1 : dataKemasan};
	dataAttr = {
		0 : { 0 : 'Jenis Pangan', 1 : 'Nama Jenis Pangan'}, 
		1 : { 0 : 'Jenis Kemasan',1 : 'Nama Jenis Kemasan'}
	};
	var getId;
	var i = 0;
	jQuery.each(obj, function(key, val){
		getId = jQuery(val).attr('id');		
		drawChart(data[i], dataAttr[i], getId);
		i++;
	});
	
	i = 0;
	//google.load("visualization", "1", {packages:["corechart"]});
	function drawChart(data, dataAttr, obj) {
		var data = google.visualization.arrayToDataTable(data);

		var options = {
		  title: dataAttr[0],
		  hAxis: {title: dataAttr[1], titleTextStyle: {color: 'red'}}
		};

		var chart = new google.visualization.ColumnChart(document.getElementById(obj));
		chart.draw(data, options);
	}
});	
</script> -->