<div style="text-align:center; padding-top:80px;">
    <img src="assets/home/img/page-under-construction.png" alt="" />
</div>