
<script type="text/javascript">
		jQuery(function($) {

				//documentation : http://docs.jquery.com/Plugins/Validation/validate
			
				$.mask.definitions['~']='[+-]';
				$('#phone').mask('(999) 999-9999');
			
				jQuery.validator.addMethod("phone", function (value, element) {
					return this.optional(element) || /^\(\d{3}\) \d{3}\-\d{4}( x\d{1,6})?$/.test(value);
				}, "Enter a valid phone number.");
			
				$('#validation-form').validate({
					errorElement: 'div',
					errorClass: 'help-block',
					focusInvalid: false,
					ignore: "",
					rules: {
						email: {
							required: true,
							email:true
						},
						password: {
							required: true,
							minlength: 5
						}
						phone: {
							required: true,
							phone: 'required'
						},
						state: {
							required: true
						}
					},
			
					messages: {
						email: {
							required: "Please provide a valid email.",
							email: "Please provide a valid email."
						},
						password: {
							required: "Please specify a password.",
							minlength: "Please specify a secure password."
						},
						state: "Please choose state",
						pemilik_usaha: "<p class='col-xs-12 col-sm-9 help-block'>Anda Belum Memilih Pemilik Usaha</p>"
					},
			
			
					highlight: function (e) {
						$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
					},
			
					success: function (e) {
						$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
						$(e).remove();
					},
			
					errorPlacement: function (error, element) {
						if(element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
							var controls = element.closest('div[class*="col-"]');
							if(controls.find(':checkbox,:radio').length > 1) controls.append(error);
							else error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
						}
						else if(element.is('.select2')) {
							error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
						}
						else if(element.is('.chosen-select')) {
							error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
						}
						else error.insertAfter(element.parent());
					},
			
					submitHandler: function (form) {
					},
					invalidHandler: function (form) {
					}
				});
				})
</script>

<style type="text/css">
	.clearfix input {
		width: 600px;
	}
	.clearfix textarea {
		margin: 0px; 
		width: 601px; 
		height: 55px;
	}
	.form-group label {
		text-align: right;
	}
</style>

<script type="text/javascript">
/*
function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	return true;
*/
	//nama perusahaan
    $(document).on('change', '#nomor_permohonan_penyuluhan', function(evt, key){
		var tgl_awal = $('#tanggal_pelatihan_awal');
		var tgl_akhir = $('#tanggal_pelatihan_akhir');
		
		var data = $(this).val();
		$.ajax({
			url	: '<?=base_url()?>pelaksanaan_pkp/get_penyuluhan_data',
			type	: 'POST',
			dataType: 'json',
			data	: 'nomor=' + data,
			success: function(html){
				$.each(html, function(key, value){					
					tgl_awal.val(value.tanggal_pelatihan_awal);
					tgl_akhir.val(value.tanggal_pelatihan_akhir);
				});
			},error: function(e){
				console.log(e);
			}
		});
	});

    $(document).on('change', '#nomor_permohonan_irtp', function(evt, key){
		var nama = $('#nama_peserta');
		
		var data = $(this).val();
		
		$.ajax({
			url	: '<?=base_url()?>pelaksanaan_pkp/get_irtp_raw',
			type	: 'POST',
			dataType: 'json',
			data	: 'nomor=' + data + '&mode=NULL',
			success: function(html){
				console.log(html);
				$.each(html, function(key, value){		
					$("#pemilik").prop('checked', true);
					nama.val(value.nama_pemilik);
				});
			},error: function(e){
				console.log(e);
			}
		});
	});
	
	$(document).on('click', '#pemilik', function(evt, key){
		var nama = $('#nama_peserta');
		
		var data = $('#nomor_permohonan_irtp').val();
		
		$.ajax({
			url	: '<?=base_url()?>pelaksanaan_pkp/get_irtp_raw',
			type	: 'POST',
			dataType: 'json',
			data	: 'nomor=' + data + '&mode=NULL',
			success: function(html){
				console.log(html);
				$.each(html, function(key, value){
					nama.val(value.nama_pemilik);
					
				});
			},error: function(e){
				console.log(e);
			}
		});
		nama.attr('readonly',true);
	});
	
	$(document).on('click', '#penanggung_jawab', function(evt, key){
		var nama = $('#nama_peserta');
		
		var data = $('#nomor_permohonan_irtp').val();
		
		$.ajax({
			url	: '<?=base_url()?>pelaksanaan_pkp/get_irtp_raw',
			type	: 'POST',
			dataType: 'json',
			data	: 'nomor=' + data + '&mode=NULL',
			success: function(html){
				console.log(html);
				$.each(html, function(key, value){					
					nama.val(value.nama_penanggung_jawab);
					
				});
			},error: function(e){
				console.log(e);
			}
		});
		nama.attr('readonly',true);
	});
	
	$(document).on('click', '#lainnya', function(evt, key){
		var nama = $('#nama_peserta');
		nama.val('');
		nama.removeAttr('readonly');
		nama.focus();
		
	});

	
	$(document).on('change', '.check-active', function(){
		if($(this).attr('checked') == "checked"){
			$(this).attr('checked', false);				
			console.log($(this).parents('.row.dropdown').find('select').prop('disabled', true).trigger('liszt:updated').select2);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").hide();
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='jenis_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nama_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nip_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='sertifikat_narasumber_lain']").prop('disabled', true);
		}else{			
			$(this).attr('checked', true);				
			$(this).parents('.row.dropdown').find('select').prop('disabled', false).trigger('liszt:updated').select2({'width' : '20%'});
			$(this).parents('.row.dropdown').find('select').find('option:first-child').prop('selected', true)
    		.end().trigger('liszt:updated').select2({'width' : '100%'});
    		// $(this).parents('.row.dropdown').find("div[id^='elemen_']").show();
    		$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='jenis_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nama_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nip_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='sertifikat_narasumber_lain']").prop('disabled', false);
		}
	});
	
	// $('.datetimepicker').datetimepicker();
	
	/*
	$("#pil_perusahaan").autocomplete({
		source: "<?php echo base_url(); ?>pb2kp/get_perusahaan" 
	});
	*/
	var perusahaan = $("#pil_perusahaan").val();
	
	$(".ui-autocomplete").click(function(){
		//$("#alamat_perusahaan").val('tes');
		var perusahaan = $("#pil_perusahaan").val();
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_alamat_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#alamat_perusahaan").val(data);
			}
		});
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_telp_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#telp_perusahaan").val(data);
			}
		}); 
	});


function cek_narasumber(x){
	var select = $('#select_narasumber_'+x).val();
	
	if(select.substr(select.length - 1)=='-'){
		$('#elemen_'+x).html('');
		$('#form_narasumber_'+x).html('');
		$('#elemen_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 1)" data-validation="required" value="Y">Bersertifikat</div> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 0)" data-validation="required" value="N">tidak Bersertifikat</div> \
			</div>\
		<div id="form_narasumber_'+x+'"></div>\
		');
		$('#elemen_'+x).show();
	} else {
		$('#elemen_'+x).html('');
		$('#form_narasumber_'+x).html('');
		$('#elemen_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 1)" value="Y">Bersertifikat</div> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 0)" value="N" checked>tidak Bersertifikat</div> \
			</div>\
			<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
	            <div class="col-md-12">NIP Narasumber</div><br>\
				<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]"></div>\
			</div>\
			<div class="col-sm-5"> \
	            <div class="col-md-12">Nama Narasumber</div><br>\
				<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]"></div>\
			</div>\
			<input class="form-control" type="text" name="sertifikat_narasumber_lain[]" style="display: none">\
		');
		$('#elemen_'+x).hide();
	}
}

function cek_jenis(x, y){
	$('#form_narasumber_'+x).html('');
	if(y==1){
		var form_narasumber = '<div class="col-md-12">NIP Narasumber</div><br>\
		<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]" data-validation="required"></div>\
		<div class="col-md-12">Nama Narasumber</div><br>\
			<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]" data-validation="required"></div><br>\
		<div class="col-md-12">Upload Sertifikat (jpg, jpeg, png, pdf)</div><br>\
		<div class="col-md-12"><input class="form-control" type="file" name="sertifikat_narasumber_lain[]" data-validation="required size mime" data-validation-max-size="2M" data-validation-allowing="jpg, png, jpeg, pdf"></div>\
		';
	} else {
		var form_narasumber = '<div class="col-md-12">NIP Narasumber</div><br>\
		<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]" data-validation="required"></div>\
		<div class="col-md-12">Nama Narasumber</div><br>\
			<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]" data-validation="required"></div>\
		<input class="form-control" type="file" name="sertifikat_narasumber_lain[]" style="display: none">\
		';
	}
	$('#form_narasumber_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
		<div class="col-sm-5"> \
            '+form_narasumber+'\
		</div>\
	');
}

$.validate({
  modules : 'file'
});

function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	return true;
}
</script>

<style>
	.chzn-container-multi {
	height:34px
	}
	.chzn-choices{
	height:34px
	}
</style>

<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
	try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
</script>

<ul class="breadcrumb">
	<li>
		<i class="ace-icon fa fa-home home-icon"></i>
		<a href="dashboard">Dashboard</a>
	</li>
	<li class="active">Input Data Pelaksanaan PKP</li>
</ul>

</div>

<div class="page-content">
    
<!-- <div class="page-header">
		<h1>
			Dashboard
			<small>
				<i class="ace-icon fa fa-angle-double-right"></i>
				Input Data Pelaksanaan PKP
			</small>
		</h1>
</div> -->
      <div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
                    <div class="row">
						<div class="col-xs-6">
							<h3 class="smaller lighter blue">Input Data Pelaksanaan PKP</h3>
						</div>
						<!-- <dir class="col-xs-6" style="text-align: right;">							
							<a href="<?php echo base_url().'role_menu/add';?>" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-edit bigger-120 blue"></i>
								Tambah Role Menu
							</a>
						</dir> -->
					</div>

					<div class="widget-box">
						<div class="widget-header widget-header-blue widget-header-flat">
							<h4 class="widget-title lighter">Pelaksanaan PKP</h4>
						</div>

									<div class="widget-body">
										<div class="widget-main">
											<div id="fuelux-wizard-container">
												<div>
													<ul class="steps">
														<li data-step="1" class="active">
															<span class="step">1</span>
															<span class="title">Penyelenggaraan Penyuluhan Keamanan Pangan</span>
														</li>

														<li data-step="2">
															<span class="step">2</span>
															<span class="title">Nama Peserta PKP</span>
														</li>

														<li data-step="3">
															<span class="step">3</span>
															<span class="title">Finish</span>
														</li>

													</ul>
												</div>

												<hr />

										<div class="step-content pos-rel">
													<div class="step-pane active" data-step="1">
													
																	<?= @$this->session->flashdata('status'); ?>
																	<?= @$this->session->flashdata('error'); ?>	
																	<?= @$this->session->flashdata('message'); ?>
																	<?=form_open_multipart('#', array('class' => 'form-horizontal','id'=>'validation-form'))?>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Tanggal Awal Penyuluhan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="input-group col-xs-12 col-sm-9">
																				<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd" name="tanggal_pelatihan_awal" placeholder="Pilih Tanggal Awal Penyuluhan" style="width: 560px;"/>
																				<span class="input-group-addon">
																					<i class="fa fa-calendar bigger-110"></i>
																				</span>
																				</div>

																				<p class="col-xs-12 col-sm-9 help-block">Pilih Tanggal Awal Penyuluhan, Contoh : 2014/08/04</p>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Tanggal Akhir Penyuluhan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="input-group col-xs-12 col-sm-9">
																				<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd" name="tanggal_pelatihan_akhir" placeholder="Pilih Tanggal Akhir Penyuluhan" style="width: 560px;"/>
																				<span class="input-group-addon">
																					<i class="fa fa-calendar bigger-110"></i>
																				</span>
																				</div>

																				<p class="col-xs-12 col-sm-9 help-block">Pilih Tanggal Akhir Penyuluhan, Contoh : 2014/08/06</p>
																		</div>
																	</div>
																	<table border="0">
																		<?php $key=0; foreach($js_materi_utama as $data): $key++; ?>
																		<tr class="row dropdown">

																			<td style="width: 260px; text-align: right;">
																				
																				<?=$data->nama_materi_penyuluhan.$key?>
																			</td>
																			<td style="width: 15px">
																				
																			</td>
																			<td>
																				<input name="form-field-checkbox" type="checkbox" class="ace input-lg form-control check-active"  checked="checked" />
																			<span class="lbl bigger-120"></span>
																			</td>

																			<td style="width: 20px">
																				
																			</td>

																			<td style="width: 520px">
																				 <select style="max-width: 550px;" id="select_narasumber_<?= $key ?>" class="select2" name="nama_narasumber[]" onchange="cek_narasumber(<?= $key ?>)">
																			<?php foreach($js_narasumber as $data_cp1): ?>
												                                <option value="<?=$data->kode_materi_penyuluhan.".".$data_cp1->kode_narasumber?>"><?=$data_cp1->nama_narasumber?></option>
												                            <?php endforeach ?>
												                            <option value="<?=$data->kode_materi_penyuluhan?>.-">Lainnya</option>			
																			
												                            </select>
												                            
																			</td>
																			<tr>
																				<td>&nbsp;</td>
																				<td>&nbsp;</td>
																				<td>&nbsp;</td>
																				<td>&nbsp;</td>
																			</tr>
																		</tr>
																		<?php endforeach ?>

																	</table>

																<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Materi Penyuluhan Tambahan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<div class="dropdown">
																				<select style="width: 600px" class="select2" multiple name="materi_tambahan[]" data-placeholder="Pilih Materi Penyuluhan Tambahan">
																				<?php foreach($js_materi_pendukung as $data): ?>
																					<option value="<?=$data->kode_materi_penyuluhan?>"><?=$data->nama_materi_penyuluhan?></option>
																				<?php endforeach ?>				
																				</select>
																			</div>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Materi Penyuluhan Tambahan, Contoh : Pencantuman Label Halal</p>
																			</div>
																		</div>
																	</div>

																	<!-- <div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Materi Penyuluhan Lainnya</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="materi_lainnya" placeholder="Masukan Materi Penyuluhan Lainnya" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Materi Penyuluhan Lainnya, Contoh : Pengolahan Makanan Yang Benar</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Peserta PKP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="nama_narasumber_non_pkp" placeholder="Masukan Nama Narasumber Non PKP"  />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Peserta PKP, Contoh : Dr. Sahidin</p>
																			</div>
																		</div>
																	</div> -->
																	
																
																	</div>
																	
													<div class="step-pane" data-step="2">
																<!-- <div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Narasumber</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="input-group col-xs-12 col-sm-9">
																				<select class="select2" id="nomor_permohonan_penyuluhan" data-validation="required" name="nomor_permohonan_penyuluhan">
																				<option value="">- Pilih Nomor Penyuluhan -</option>
																			<?php //foreach($no_penyuluhan as $data): ?>
																				<option value="<?=$data->nomor_permohonan_penyuluhan?>"><?=$data->nama_narasumber_non_pkp?> </option>
																			<?php //endforeach ?>				
																			</select>
																				</div>
																				<p class="col-xs-12 col-sm-9 help-block"></p>
																		</div>
																	</div> -->
																	<div class="table-responsive text-nowrap">
																		<table border="1"  class="table table-striped table-bordered table-hover" >
																		<thead>
																			<tr>
																				<td>Nomor Permohonan IRTP</td>
																				<td>Status Peserta Penyuluhan</td>
																				<td>Nama Peserta Penyuluhan</td>
																				<td>Nilai Pre Test</td>
																				<td>Nilai Post Test</td>
																				<td><div class="btn btn-sm btn-primary" style="width:65px">Add</div></td>
																			</tr>
																		</thead>
																		<tbody>
																			<tr>
																				<td>
																					<select style="max-width: 380px" class="select2" id="nomor_permohonan_irtp" data-validation="required" name="nomor_permohonan_irtp">
																					<option value="">- Pilih Nomor Permohonan IRTP -</option>
																					<?php foreach($no_irtp as $data): ?>
																					<option value="<?=$data->nomor_permohonan?>"><?=$data->nomor_permohonan.' - '.$data->nama_perusahaan.' - '. $data->nama_pemilik.' - '.$data->nama_dagang?> </option>
																					<?php endforeach ?>				
																				</select>
																				</td>
																				<td>
																					<label class="checkbox-inline">
																						<input type="radio" class="ace status_pengajuan" id="pemilik" name="status_peserta" value="0" >
																						<span class="lbl"> Pemilik IRTP </span>
																					</label>
																					<label class="checkbox-inline">
																						<input type="radio" class="ace status_pengajuan" id="penanggung_jawab" name="status_peserta" value="1">
																						<span class="lbl"> Penanggung Jawab IRTP </span>
																					</label>
																					<label class="checkbox-inline">
																						<input type="radio" class="ace status_pengajuan" id="lainnya" name="status_peserta" value="2" ><span class="lbl">  Lainnya </span>
																					</label>
																				</td>
																				<td>
																					<input type="text" name="nama_peserta" id="nama_peserta" placeholder="Pilih Nomor Permohonan IRTP terlebih dahulu atau isi peserta lainnya" readonly />	
																				</td>
																				<td >
																					<input type="text" name="nilai_pre_test" data-validation="number" data-validation-allowing="range[0;99999]" onkeypress="return isNumberKey(event)" maxlength="3" placeholder="Masukan Nilai Pre Test"/>
																				</td>
																				<td>
																					<input type="text" name="nilai_post_test" data-validation="number" data-validation-allowing="range[0;99999]" onkeypress="return isNumberKey(event)" maxlength="3" placeholder="Masukan Nilai Post Test"/>
																				</td>
																				<td></td>

																			</tr>
																		</tbody>
																		</table>	
																	</div>
													</div>
<?=form_close()?>

													<div class="step-pane" data-step="3">
																<div class="center">
																	<h3 class="green">Data Anda Sudah Terisi Semua.</h3>
																	<b>Pastikan data inputan yang Anda masukkan sudah benar. Silahkan lakukan pengecekan jika terdapat kesalahan input. <br>Tekan tombol Selesai di bawah ini untuk mengakhiri proses inputan dan menyimpan data inputan.</b>
																</div>
													</div>

												</div>
											</div>

											<hr />
											<div class="wizard-actions">
											
												
												<button class="btn btn-prev">
													<i class="ace-icon fa fa-arrow-left"></i>
													Sebelumnya
												</button>

												<button id='btn-submit' class="btn btn-warning btn-next" data-last="Selesai">
													Selanjutnya
													<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
												</button>
												
											</div>
                                        </div>

				</div>
			</div>
		</div>
	</div>

</div>



<script  type="text/javascript">
    
    $('#btn-submit').click(function(){
        if($(this).html().includes($(this).attr('data-last'))){
            save_data();
        }
    });
    
    function save_data()
    {
        $.ajax({
           url:'<?php echo base_url()?>pelaksanaan_pkp/add',
           type:'POST',
           data:$("#validation-form").serialize(),
           dataType:'json',
           success:function(response){
               if(response.success)
               {
                    //alert('Data Tersimpan!');
                    window.location.href='<?php echo base_url()?>pelaksanaan_pkp/output_penyelenggaraan';
               }
               else{
                   alert('Data Gagal Tersimpan');
               }
           },
           error:function(stat,res,err)
           {
               alert(err);
           }
        });
    }
    
    /*
    Non file
    data:JSON.stringify($('#form-input'))
    
    File
    new FormData($('#form-input'))
    
    */
    
</script>
