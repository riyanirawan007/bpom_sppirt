<script type="text/javascript">
/*
function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	return true;
*/
$(document).ready(function() {
	//nama perusahaan
	var config = {
      '.select2'           : {},
      '.select-deselect'  : {allow_single_deselect:true},
      '.select-no-single' : {disable_search_threshold:10},
      '.select-no-results': {no_results_text:'Oops, nothing found!'},
      '.select-width'     : {width:"100%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
	
	$(document).on('change', '.check-active', function(){
		if($(this).attr('checked') == "checked"){
			$(this).attr('checked', false);				
			console.log($(this).parents('.row.dropdown').find('select').prop('disabled', true).trigger('liszt:updated').chosen);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").hide();
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='jenis_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nama_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nip_narasumber_lain']").prop('disabled', true);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='sertifikat_narasumber_lain']").prop('disabled', true);
		}else{			
			$(this).attr('checked', true);				
			$(this).parents('.row.dropdown').find('select').prop('disabled', false).trigger('liszt:updated').chosen({'width' : '20%'});
			$(this).parents('.row.dropdown').find('select').find('option:first-child').prop('selected', true)
    		.end().trigger('liszt:updated').chosen({'width' : '20%'});
    		// $(this).parents('.row.dropdown').find("div[id^='elemen_']").show();
    		$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='jenis_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nama_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='nip_narasumber_lain']").prop('disabled', false);
			$(this).parents('.row.dropdown').find("div[id^='elemen_']").find("input[name^='sertifikat_narasumber_lain']").prop('disabled', false);
		}
	});
	
	$('.datetimepicker').datetimepicker();
	
	/*
	$("#pil_perusahaan").autocomplete({
		source: "<?php echo base_url(); ?>pb2kp/get_perusahaan" 
	});
	*/
	var perusahaan = $("#pil_perusahaan").val();
	
	$(".ui-autocomplete").click(function(){
		//$("#alamat_perusahaan").val('tes');
		var perusahaan = $("#pil_perusahaan").val();
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_alamat_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#alamat_perusahaan").val(data);
			}
		});
		
		$.ajax({
			type: "POST",
			url:"<?php echo base_url(); ?>pb2kp/get_telp_perusahaan",
			data:"perusahaan="+perusahaan,
			success: function(data){
				$("#telp_perusahaan").val(data);
			}
		}); 
	});


});

function cek_narasumber(x){
	var select = $('#select_narasumber_'+x).val();
	
	if(select.substr(select.length - 1)=='-'){
		$('#elemen_'+x).html('');
		$('#form_narasumber_'+x).html('');
		$('#elemen_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 1)" data-validation="required" value="Y">Bersertifikat</div> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 0)" data-validation="required" value="N">tidak Bersertifikat</div> \
			</div>\
		<div id="form_narasumber_'+x+'"></div>\
		');
		$('#elemen_'+x).show();
	} else {
		$('#elemen_'+x).html('');
		$('#form_narasumber_'+x).html('');
		$('#elemen_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 1)" value="Y">Bersertifikat</div> \
                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain['+x+']" onclick="cek_jenis('+x+', 0)" value="N" checked>tidak Bersertifikat</div> \
			</div>\
			<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
			<div class="col-sm-5"> \
	            <div class="col-md-12">NIP Narasumber</div><br>\
				<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]"></div>\
			</div>\
			<div class="col-sm-5"> \
	            <div class="col-md-12">Nama Narasumber</div><br>\
				<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]"></div>\
			</div>\
			<input class="form-control" type="file" name="sertifikat_narasumber_lain[]" style="display: none">\
		');
		$('#elemen_'+x).hide();
	}
}

function cek_jenis(x, y){
	$('#form_narasumber_'+x).html('');
	if(y==1){
		var form_narasumber = '<div class="col-md-12">NIP Narasumber</div><br>\
		<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]" data-validation="required"></div>\
		<div class="col-md-12">Nama Narasumber</div><br>\
			<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]" data-validation="required"></div><br>\
		<div class="col-md-12">Upload Sertifikat (jpg, jpeg, png, pdf)</div><br>\
		<div class="col-md-12"><input class="form-control" type="file" name="sertifikat_narasumber_lain[]" data-validation="required size mime" data-validation-max-size="2M" data-validation-allowing="jpg, png, jpeg, pdf"></div>\
		';
	} else {
		var form_narasumber = '<div class="col-md-12">NIP Narasumber</div><br>\
		<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]" data-validation="required"></div>\
		<div class="col-md-12">Nama Narasumber</div><br>\
			<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]" data-validation="required"></div>\
		<input class="form-control" type="file" name="sertifikat_narasumber_lain[]" style="display: none">\
		';
	}
	$('#form_narasumber_'+x).html('<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> \
		<div class="col-sm-5"> \
            '+form_narasumber+'\
		</div>\
	');
}

$.validate({
  modules : 'file'
});

</script>	
<style>
	.chzn-container-multi {
	height:34px
	}
	.chzn-choices{
	height:34px
	}
</style>

<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
	try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
</script>

<ul class="breadcrumb">
	<li>
		<i class="ace-icon fa fa-home home-icon"></i>
		<a href="dashboard">Dashboard</a>
	</li>
	<li class="active">Input Data Pelaksanaan PKP</li>
</ul>

</div>

<div class="page-content">
    
<!-- <div class="page-header">
		<h1>
			Dashboard
			<small>
				<i class="ace-icon fa fa-angle-double-right"></i>
				Input Data Pelaksanaan PKP
			</small>
		</h1>
</div> -->
      <div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
                    <div class="row">
						<div class="col-xs-6">
							<h3 class="smaller lighter blue">Input Data Pelaksanaan PKP</h3>
						</div>
						<!-- <dir class="col-xs-6" style="text-align: right;">							
							<a href="<?php echo base_url().'role_menu/add';?>" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-edit bigger-120 blue"></i>
								Tambah Role Menu
							</a>
						</dir> -->
					</div>

					<div class="widget-box">
						<div class="widget-header widget-header-blue widget-header-flat">
							<h4 class="widget-title lighter">Pelaksanaan PKP</h4>
						</div>

									<div class="widget-body">
										<div class="widget-main">
											<div id="fuelux-wizard-container">
												<div>
													<ul class="steps">
														<li data-step="1" class="active">
															<span class="step">1</span>
															<span class="title">Penyelenggaraan Penyuluhan Keamanan Pangan</span>
														</li>


														<li data-step="2">
															<span class="step">2</span>
															<span class="title">Finish</span>
														</li>

													</ul>
												</div>

												<hr />

										<div class="step-content pos-rel">
													<div class="step-pane active" data-step="1">
													
																	<?= @$this->session->flashdata('status'); ?>
																	<?= @$this->session->flashdata('error'); ?>	
																	<?= @$this->session->flashdata('message'); ?>
																	<?php $attr_form = array('onsubmit' => 'return cek_form()'); ?>	
																	<?=form_open_multipart('pelaksanaan_pkp/add', array('class' => 'form-horizontal'), $attr_form)?>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Tanggal Awal Penyuluhan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="date" class="col-xs-12 col-sm-9" name="tanggal_pelatihan_awal" placeholder="Pilih Tanggal Awal Penyuluhan" data-validation="required" />
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Tanggal Awal Penyuluhan, Contoh : 2014/08/04</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Tanggal Akhir Penyuluhan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="date" class="col-xs-12 col-sm-9"  name="tanggal_pelatihan_akhir" placeholder="Pilih Tanggal Akhir Penyuluhan" data-validation="required" />
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Tanggal Akhir Penyuluhan, Contoh : 2014/08/06</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Nama Narasumber Non PKP</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="nama_narasumber_non_pkp" placeholder="Masukan Nama Narasumber Non PKP"  />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Nama Narasumber Non PKP, Contoh : Dr. Sahidin</p>
																			</div>
																		</div>
																	</div>

																<div class="form-group">        
												                    <?php $key=0; foreach($js_materi_utama as $data): $key++; ?>
																	<div class="row dropdown" >
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">
																			<div class="clearfix">
																			<?=$data->nama_materi_penyuluhan.$key?>
																		</div>
																		</label>
												                        
												                        <div class="col-sm-1">
												                        	<input type="checkbox" checked="checked" class="form-control check-active" />
												                        </div>                 
												                        <div class="col-sm-5">
												                            <select id="select_narasumber_<?= $key ?>" class="select2 col-sm-12" name="nama_narasumber[]" onchange="cek_narasumber(<?= $key ?>)">
																			<?php foreach($js_narasumber as $data_cp1): ?>
												                                <option value="<?=$data->kode_materi_penyuluhan.".".$data_cp1->kode_narasumber?>"><?=$data_cp1->nama_narasumber?></option>
												                            <?php endforeach ?>
												                            <option value="<?=$data->kode_materi_penyuluhan?>.-">Lainnya</option>			
																			
												                            </select>
																		</div>
																		<div id="elemen_<?= $key ?>" style="display: none;">
																			<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> 
																			<div class="col-sm-5"> 
																                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain[<?= $key ?>]" value="Y">Bersertifikat</div> 
																                <div class="col-sm-6"><input type="radio" name="jenis_narasumber_lain[<?= $key ?>]" value="N" checked>tidak Bersertifikat</div> 
																			</div>
																			<div class="col-sm-6" style="padding-top : 10px"></div><div class="col-sm-1"></div> 
																			<div class="col-sm-5"> 
																	            <div class="col-md-12">NIP Narasumber</div><br>
																				<div class="col-md-12"><input class="form-control" type="text" name="nip_narasumber_lain[]"></div>
																			</div>
																			<div class="col-sm-5"> 
																	            <div class="col-md-12">Nama Narasumber</div><br>
																				<div class="col-md-12"><input class="form-control" type="text" name="nama_narasumber_lain[]"></div>
																			</div>
																			<input type="file" name="sertifikat_narasumber_lain[]" style="display: none">
																		</div>

																	</div>
												                    <?php endforeach ?>				
																</div>

																<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Materi Penyuluhan Tambahan</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<div class="dropdown">
																				<select class="form-control chosen-select col-xs-12 col-sm-9" multiple name="materi_tambahan[]" data-placeholder="Pilih Materi Penyuluhan Tambahan">
																				<?php foreach($js_materi_pendukung as $data): ?>
																					<option value="<?=$data->kode_materi_penyuluhan?>"><?=$data->nama_materi_penyuluhan?></option>
																				<?php endforeach ?>				
																				</select>
																			</div>
																				<p class="col-xs-12 col-sm-9 help-block">Pilih Materi Penyuluhan Tambahan, Contoh : Pencantuman Label Halal</p>
																			</div>
																		</div>
																	</div>

																	<div class="form-group">
																		<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="text">Materi Penyuluhan Lainnya</label>

																		<div class="col-xs-12 col-sm-9">
																			<div class="clearfix">
																				<input type="text" class="col-xs-12 col-sm-9" name="materi_lainnya" placeholder="Masukan Materi Penyuluhan Lainnya" />
																				<p class="col-xs-12 col-sm-9 help-block">Masukan Materi Penyuluhan Lainnya, Contoh : Pengolahan Makanan Yang Benar</p>
																			</div>
																		</div>
																	</div>
																	
																
																	</div>
																	
													


													<div class="step-pane" data-step="2">
																<div class="center">
																	<h3 class="green">Data Anda Sudah Terisi Semua.</h3>
																	<b>Pastikan data inputan yang Anda masukkan sudah benar. Silahkan lakukan pengecekan jika terdapat kesalahan input. <br>Tekan tombol Selesai di bawah ini untuk mengakhiri proses inputan dan menyimpan data inputan.</b>
																</div>
															</div>

												</div>
											</div>

											<hr />
											<div class="wizard-actions">
											
												
												<button class="btn btn-prev">
													<i class="ace-icon fa fa-arrow-left"></i>
													Sebelumnya
												</button>

												<button class="btn btn-warning btn-next" data-last="Selesai">
													Selanjutnya
													<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
												</button>
												<?=form_close()?>
											</div>
                                        </div>

				</div>
			</div>
		</div>
	</div>

</div>

