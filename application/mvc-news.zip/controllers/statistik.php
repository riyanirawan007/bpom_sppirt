<?php
class Statistik extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('rekap_irtp_model','rekap_irtp');
		$this->load->model('menu_model');	
		if(checkUserAuthorize()) checkMenuAuthority();
	}
	
	function index(){
		return view_dashboard('statistik/sppirt_pengajuan');
	}
	
	function sppirt_pengajuan(){
		return view_dashboard('statistik/sppirt_pengajuan');
	}
}