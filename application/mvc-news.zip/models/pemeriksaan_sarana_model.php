<?php

class Pemeriksaan_sarana_model extends CI_Model{


}