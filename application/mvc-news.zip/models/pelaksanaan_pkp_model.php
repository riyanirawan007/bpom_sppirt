<?php

class Pelaksanaan_pkp_model extends CI_Model{


}