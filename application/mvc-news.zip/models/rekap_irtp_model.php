<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rekap_irtp_model extends CI_Model {
	
	function get_pengajuan($params=array()){
		$sql="SELECT a.*, b.*,
		(
		SELECT COUNT(tabel_pen_pengajuan_spp.nomor_permohonan)
		FROM tabel_pen_pengajuan_spp
		INNER JOIN tabel_daftar_perusahaan ON tabel_daftar_perusahaan.kode_perusahaan=tabel_pen_pengajuan_spp.kode_r_perusahaan
		INNER JOIN tabel_teknologi_pengolahan ON tabel_pen_pengajuan_spp.kode_r_tek_olah = tabel_teknologi_pengolahan.kode_tek_olah
		INNER JOIN tabel_jenis_pangan ON tabel_pen_pengajuan_spp.id_urut_jenis_pangan = tabel_jenis_pangan.id_urut_jenis_pangan
		INNER JOIN tabel_kemasan ON tabel_pen_pengajuan_spp.kode_r_kemasan = tabel_kemasan.kode_kemasan
		left join tabel_scan_data_pengajuan_rl on tabel_scan_data_pengajuan_rl.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan
		left join tabel_scan_data_pengajuan_siup on tabel_scan_data_pengajuan_siup.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
		left join tabel_scan_data_pengajuan_ap on tabel_scan_data_pengajuan_ap.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
		WHERE tabel_daftar_perusahaan.id_r_urut_kabupaten=b.id_urut_kabupaten  
		";
		
		if($params['jenis_pangan']){
			$sql.=" AND tabel_pen_pengajuan_spp.id_urut_jenis_pangan=".$params['jenis_pangan'];
		}
		
		$sql.="
			) as jumlah
			,(
			SELECT COUNT(tabel_pen_pengajuan_spp.nomor_permohonan)
			FROM tabel_pen_pengajuan_spp
			INNER JOIN tabel_daftar_perusahaan ON tabel_daftar_perusahaan.kode_perusahaan=tabel_pen_pengajuan_spp.kode_r_perusahaan
			INNER JOIN tabel_teknologi_pengolahan ON tabel_pen_pengajuan_spp.kode_r_tek_olah = tabel_teknologi_pengolahan.kode_tek_olah
			INNER JOIN tabel_jenis_pangan ON tabel_pen_pengajuan_spp.id_urut_jenis_pangan = tabel_jenis_pangan.id_urut_jenis_pangan
			INNER JOIN tabel_kemasan ON tabel_pen_pengajuan_spp.kode_r_kemasan = tabel_kemasan.kode_kemasan
			INNER JOIN tabel_kabupaten_kota ON tabel_kabupaten_kota.id_urut_kabupaten=tabel_daftar_perusahaan.id_r_urut_kabupaten
			INNER JOIN tabel_propinsi ON tabel_kabupaten_kota.no_kode_propinsi=tabel_propinsi.no_kode_propinsi
			left join tabel_scan_data_pengajuan_rl on tabel_scan_data_pengajuan_rl.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan
			left join tabel_scan_data_pengajuan_siup on tabel_scan_data_pengajuan_siup.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
			left join tabel_scan_data_pengajuan_ap on tabel_scan_data_pengajuan_ap.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
			WHERE tabel_propinsi.no_kode_propinsi=a.no_kode_propinsi
			GROUP BY tabel_propinsi.no_kode_propinsi
			) as jumlah_per_prov
			FROM tabel_propinsi a
			INNER JOIN tabel_kabupaten_kota b ON a.no_kode_propinsi=b.no_kode_propinsi";
		
		if($params['prov']!=null)
		{
			$sql.=" AND a.no_kode_propinsi=".$params['prov'];
		}
		if($params['kab']!=null)
		{
			$sql.=" AND b.id_urut_kabupaten=".$params['kab'];
		}
		
		$data=$this->db->query($sql)->result_array();
		
		$i=0;
		foreach($data as $d){
			$d['no']=($i+1);
			$data[$i]=$d;
			$i++;
		}
		
		return $data;
	}

	function get_penerbitan($params=array())
	{
		/*$sql="SELECT a.*,b.*,
		( 
			SELECT COUNT(*) 
			FROM tabel_penerbitan_sert_pirt 
			inner join tabel_pen_pengajuan_spp on tabel_penerbitan_sert_pirt.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan
			inner join tabel_daftar_perusahaan on tabel_pen_pengajuan_spp.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
			inner join tabel_kabupaten_kota on tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten
			inner join tabel_propinsi on tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi
			where tabel_penerbitan_sert_pirt.status_pencabutan=0
			and tabel_kabupaten_kota.id_urut_kabupaten=b.id_urut_kabupaten
		) as jumlah,
		( 
			SELECT COUNT(*) 
			FROM tabel_penerbitan_sert_pirt 
			inner join tabel_pen_pengajuan_spp on tabel_penerbitan_sert_pirt.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan
			inner join tabel_daftar_perusahaan on tabel_pen_pengajuan_spp.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan
			inner join tabel_kabupaten_kota on tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten
			inner join tabel_propinsi on tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi
			where tabel_penerbitan_sert_pirt.status_pencabutan=0
			and tabel_propinsi.no_kode_propinsi=a.no_kode_propinsi
		) as jumlah_per_prov
		FROM tabel_propinsi as a
		INNER JOIN tabel_kabupaten_kota as b ON a.no_kode_propinsi=b.no_kode_propinsi";*/

		$sql="
		SELECT a.*,b.* FROM tabel_propinsi a
		INNER JOIN tabel_kabupaten_kota b ON a.no_kode_propinsi=b.no_kode_propinsi	
		";
		
		if($params['prov']!=null)
		{
			$sql.=" AND a.no_kode_propinsi=".$params['prov'];
		}
		if($params['kab']!=null)
		{
			$sql.=" AND b.id_urut_kabupaten=".$params['kab'];
		}
		
		$data=$this->db->query($sql)->result_array();
		$i=0;
		foreach($data as $d)
		{
			$sql_jumlah="SELECT COUNT(tabel_penerbitan_sert_pirt.id_urut_penerbitan_sert) as jumlah FROM tabel_penerbitan_sert_pirt left join tabel_pencabutan_pirt on tabel_penerbitan_sert_pirt.id_urut_penerbitan_sert = tabel_pencabutan_pirt.id_r_urut_penerbitan_sert_pirt, tabel_pen_pengajuan_spp, tabel_daftar_perusahaan, tabel_propinsi, tabel_kabupaten_kota WHERE tabel_pen_pengajuan_spp.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan and tabel_penerbitan_sert_pirt.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan and tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi and tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten AND tabel_pencabutan_pirt.id_r_urut_penerbitan_sert_pirt is null and tabel_kabupaten_kota.id_urut_kabupaten=".$d['id_urut_kabupaten'];
			$data_jumlah=$this->db->query($sql_jumlah)->row_array();
			$d['jumlah']=$data_jumlah['jumlah'];
			$sql_jumlah_prov="SELECT COUNT(tabel_penerbitan_sert_pirt.id_urut_penerbitan_sert) as jumlah_per_prov FROM tabel_penerbitan_sert_pirt left join tabel_pencabutan_pirt on tabel_penerbitan_sert_pirt.id_urut_penerbitan_sert = tabel_pencabutan_pirt.id_r_urut_penerbitan_sert_pirt, tabel_pen_pengajuan_spp, tabel_daftar_perusahaan, tabel_propinsi, tabel_kabupaten_kota WHERE tabel_pen_pengajuan_spp.kode_r_perusahaan = tabel_daftar_perusahaan.kode_perusahaan and tabel_penerbitan_sert_pirt.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan and tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi and tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten AND tabel_pencabutan_pirt.id_r_urut_penerbitan_sert_pirt is null and tabel_propinsi.no_kode_propinsi=".$d['no_kode_propinsi'];
			$data_jumlah_prov=$this->db->query($sql_jumlah_prov)->row_array();
			$d['jumlah_per_prov']=$data_jumlah_prov['jumlah_per_prov'];
			$d['no']=($i+1);
			$data[$i]=$d;
			$i++;
		}
		return $data;
	}
	
	function get_prov(){
		return $this->db->get('tabel_propinsi')->result_array();
	}
	
	function get_kab(){
		$id_prov=$this->input->get('prov');
		return $this->db
		->select('*')
		->from('tabel_kabupaten_kota')
		->where('no_kode_propinsi',$id_prov)
		->get()->result_array();
	}
}