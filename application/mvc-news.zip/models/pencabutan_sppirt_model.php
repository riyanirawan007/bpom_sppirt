<?php

class Pencabutan_sppirt_model extends CI_Model{


}