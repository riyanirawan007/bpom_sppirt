<?php

class Perpanjangan_sertifikat_model extends CI_Model{


}