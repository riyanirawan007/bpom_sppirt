<?php

class Penerbitan_sertifikat_model extends CI_Model{


}