<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rekap_jumlah_pkp_dfi_model extends CI_Model {

	function view()
	{
		return $this->db->get('');
	}

}