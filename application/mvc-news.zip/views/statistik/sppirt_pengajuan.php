<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
		try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
	</script>

	<ul class="breadcrumb">
		<li>
			<i class="ace-icon fa fa-home home-icon"></i>
			<a href="dashboard">Dashboard</a>
		</li>
		<li class="active">Data Rekap Pengajuan</li>
	</ul>

</div>

<div class="page-content">
	<div class="row">
		<div class="col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="row">
				<div class="col-xs-12">
					<div class="row">
						<div class="col-xs-4">
							<h3 class="smaller lighter blue">Statistik Pengajuan SPP-IRT</h3>
						</div>
						<div class="col-xs-3" style="margin-top:15px;">
							<select id="fprov" class="form-control">
								<option value="">Seluruh Provinsi</option>
							</select>
						</div>
						<div class="col-xs-3" style="margin-top:15px;">
							<select id="fkab" class="form-control">
								<option value="">Seluruh Kabupaten</option>
							</select>
						</div>
						<dir class="col-xs-2" style="text-align: left; margin-top:15px;">
							<button id="fsend" class="btn btn-white btn-info btn-bold">
								<i class="ace-icon fa fa-filter bigger-120 blue"></i>
								Filter
							</button>					
						</dir>
					</div>
					
					<div id="container" style="min-width: 310px; height: 700px; margin: 0 auto"></div>

					
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script>
$('document').ready(function(){
	var jum_prov=0;
	var mChart;
	var cats=[];

	mChart=Highcharts.chart('container', {
    chart: {
        type: 'bar'
    },
    title: {
        text: 'Statistik Pengajuan SPP-IRT'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
		categories: cats,
        labels: {
                        enabled:true,
                        rotation: 0,
                        style: {
                            fontSize:'14px'
                        }
                    },
                    title: {
                        text: null
                    }
    },
    yAxis: {
        allowDecimals: false,
                    min: 0,
                    title: {
                        userHTML:true,
                        text: '<b style="font-size:16px;">Total</b>'
                    },
                    labels: {
                        overflow: 'justify'
                    }
    },
    tooltip: {
        valueSuffix: ' buah'
    },
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: true
            }
        },
		series: {
                     colorByPoint:true,
                     pointPadding: 0,
                     pointWidth:16,
                     groupPadding: 0.05  
                 }
		
    },
    credits: {
        enabled: false
    },
    series: [{
        data: []
		}]
	
	});

	getProv();
	
	function getProv(){
		$.ajax({
			url:'http://sppirt.sahabatjasa.com/rekap_pengajuan/prov',
			type:'GET',
			dataType:'json',
			success:function(response){
				var opt='<option value="">Seluruh Provinsi</option>';
				var values=[];
				for(var i=0;i<response.length;i++)
				{
					opt+='<option value="'+response[i].no_kode_propinsi+'">'+response[i].nama_propinsi+'</option>';
					cats[i]=''+response[i].nama_propinsi;
					values[i]=Math.round( Math.random(1,100)*100, 0);
				}
				$('#fprov').html(opt);
				mChart.xAxis.categories=cats;
				mChart.series[0].setData(values);
				mChart.redraw();
			},
			error:function(err){
				alert(err);
			}
		});
	}
	
	function getKab(){
		$.ajax({
			url:'http://sppirt.sahabatjasa.com/rekap_pengajuan/kab',
			type:'GET',
			dataType:'json',
			data:{
				prov:$('#fprov').val()
			},
			success:function(response){
				var opt='<option value="">Seluruh Kabupaten</option>';
				for(var i=0;i<response.length;i++)
				{
					opt+='<option value="'+response[i].id_urut_kabupaten+'">'+response[i].nm_kabupaten+'</option>';
				}
				$('#fkab').html(opt);
			},
			error:function(err){
				alert(err);
			}
		});
	}
	
	$('#fprov').change(function(){
		getKab();
	});
	
	$('#fsend').click(function(){
		jum_prov=0;
		getProv();
	});

	$('#report').click(function(){
		window.open(
			'http://sppirt.sahabatjasa.com/rekap_pengajuan/rekap' +
			'?prov=' + $('#fprov').val() +
			'&kab=' + $('#fkab').val()+
			'&prov_name=' + $('#fprov option:selected').text()+
			'&kab_name=' + $('#fkab option:selected').text()
		);
	});


});
</script>