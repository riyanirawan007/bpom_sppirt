<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pelaksanaan_pkp extends APP_Controller {

public function __construct()
	{
		parent::__construct();
		//load library dan helper yang dibutuhkan
		// $this->load->library('lib_irtp');
		$this->load->helper('url', 'form');
		$this->load->library('form_validation');
		$this->load->model('pelaksanaan_pkp_model','',TRUE);
		$this->load->model('irtp_model','',TRUE);
	}

	public function index()
	{
		return view_dashboard('irtp/pelaksanaan_pkp/input_pkp');
	}
	
	public function output_penyelenggaraan()
	{
		if($this->session->userdata('user_segment')==4 or $this->session->userdata('user_segment')==3){
			if($this->input->post('no_kode_propinsi')!=""){
				$provinsi = $this->input->post('no_kode_propinsi');
			} else {
				$provinsi = $this->session->userdata('code');
			}
		} else {
			$provinsi = $this->input->post('no_kode_propinsi');
		}
		
		if($this->session->userdata('user_segment')==5){
			if($this->input->post('nama_kabupaten')!=""){
				$kabupaten = $this->input->post('nama_kabupaten');
			} else {
				$kabupaten = $this->session->userdata('code');
			}
		} else {
			$kabupaten = $this->input->post('nama_kabupaten');
		}
		
		if($provinsi!=""){ $q_provinsi = "and tabel_propinsi.no_kode_propinsi='$provinsi'"; } else { $q_provinsi = ""; }
		if($kabupaten!=""){ $q_kabupaten = "and tabel_kabupaten_kota.id_urut_kabupaten in ($kabupaten)"; } else { $q_kabupaten = ""; }
		
		$tanggal_awal = $this->input->post('tanggal_awal');
		$tanggal_akhir = $this->input->post('tanggal_akhir');
		if($tanggal_awal!=""){
			$tanggal_awal = date('Y-m-d', strtotime($this->input->post('tanggal_awal')));
		}
		if($tanggal_akhir!=""){
			$tanggal_akhir = date('Y-m-d', strtotime($this->input->post('tanggal_akhir')));
		}
		
		//load data permohonan
		$datas = $this->irtp_model->penyelenggaraan_view($provinsi,$kabupaten,$tanggal_awal,$tanggal_akhir)->result();	
		$data['datas'] = $this->irtp_model->penyelenggaraan_view($provinsi,$kabupaten,$tanggal_awal,$tanggal_akhir)->result();
		
		//generate table data
		$this->load->library('table');
		$this->table->set_empty("&nbsp;");
		
		//head
		$tmpl = array ( 'table_open'  => '<table class="table table-bordered" id="data_table">' );
		$this->table->set_template($tmpl);
		
		$this->table->set_heading(
			'No.',
			'No. Permohonan Penyuluhan',
			'Tanggal Awal Penyuluhan',
			'Tanggal Akhir Penyuluhan',
			'Provinsi',
			'Kabupaten/Kota',
			#'Nama Narasumber PKP',
			'Nama Narasumber Non PKP',
			'Narasumber Berdasarkan Materi Penyuluhan',
			'Materi Penyuluhan Tambahan',
			'Materi Penyuluhan Lainnya',
			'Daftar Peserta',
			'Laporan Penyelenggaraan'
		);
		
		//isi
		$i = 0;
		foreach($datas as $field){
		
			$get_materi = $this->db->query("select * from tabel_ambil_materi_penyuluhan ambil
			left join tabel_materi_penyuluhan materi on ambil.kode_r_materi_penyuluhan = materi.kode_materi_penyuluhan
			left join tabel_narasumber nara on ambil.kode_r_narasumber = nara.kode_narasumber
			where ambil.nomor_r_permohonan_penyuluhan = '".$field->nomor_permohonan_penyuluhan."'")->result();
			
			/* $no_materi = 0;
			$materi_penyuluhan = "";
			 */
			$arr_materi = array();
			foreach($get_materi as $row){
				//$no_materi++;
				$arr_materi[] = $row->kode_r_materi_penyuluhan;
				//$materi_penyuluhan .= $no_materi.". ".$row->nama_materi_penyuluhan." oleh : ".$row->nama_narasumber."<br>";
				
			}
			$materi_penyuluhan = implode(',', $arr_materi);
			
			
			$xplod_tambahan = explode(",",$field->materi_tambahan);
			$no_materi = 0;
			$materi_tambahan = "";
			foreach($xplod_tambahan as $row_tambahan){
				$get_materi = $this->db->query("select * from tabel_materi_penyuluhan
				where kode_materi_penyuluhan = '".$row_tambahan."'")->result();
				
				foreach($get_materi as $row){
					$no_materi++;
					$materi_tambahan .= $no_materi.". ".$row->nama_materi_penyuluhan."<br>";
				}
			}
			
			$this->table->add_row(++$i,
			$field->nomor_permohonan_penyuluhan,
			date('d-m-Y', strtotime($field->tanggal_pelatihan_awal)),
			date('d-m-Y', strtotime($field->tanggal_pelatihan_akhir)),
			$field->nama_propinsi,
			$field->nm_kabupaten,
			$field->nama_narasumber_non_pkp,
			$materi_penyuluhan,
			$materi_tambahan,
			$field->materi_pelatihan_lainnya,
			anchor('irtp/output_laporan_daftar_peserta/'.$field->nomor_permohonan_penyuluhan, 'Daftar Peserta', array('class' => 'btn btn-info', 'target' => '_blank')),
			anchor('irtp/output_laporan_penyelenggaraan_unduh/'.$field->nomor_permohonan_penyuluhan, 'Laporan', array('class' => 'btn btn-info col-md-12', 'target' => '_blank'))
			);
		}
		
		$data['table'] = $this->table->generate();
		
		if($provinsi!='' or $kabupaten!=''){
			if($this->session->userdata('user_segment')==5){
				$kab = $this->db->query("select * from tabel_propinsi join tabel_kabupaten_kota on tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi where id_urut_kabupaten in (".$this->session->userdata('code').")")->result();
				
				$data['filter_kab'] = "";
				foreach($kab as $r){
					$prov_arr[] = $r->no_kode_propinsi;
					if($r->id_urut_kabupaten==$kabupaten){
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten' selected>$r->no_kabupaten. $r->nm_kabupaten</option>";
					} else {
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten'>$r->no_kabupaten. $r->nm_kabupaten</option>";
					}
				}
				$prov = $this->db->query("select * from tabel_propinsi where no_kode_propinsi in (".implode(",",$prov_arr).")")->result();
			} else {
				$prov = $this->db->query("select * from tabel_propinsi where no_kode_propinsi='$provinsi'")->result();
				foreach($prov as $r){
					$kode_propinsi = $r->no_kode_propinsi;
					$nama_propinsi = $r->nama_propinsi;
				}
				$data['filter'] = "<option value='$kode_propinsi' selected>$nama_propinsi</option><option disabled>- Pilih Provinsi -</option>";
				
				$kab = $this->db->query("select * from tabel_kabupaten_kota where no_kode_propinsi='$provinsi'")->result();
				$data['filter_kab'] = "";
				foreach($kab as $r){
					if($r->id_urut_kabupaten==$kabupaten){
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten' selected>$r->no_kabupaten. $r->nm_kabupaten</option>";
					} else {
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten'>$r->no_kabupaten. $r->nm_kabupaten</option>";
					}
				}
			}
			
			$data['jumlah_industri_pangan'] = $this->db->query("SELECT * FROM tabel_penyelenggara_penyuluhan, tabel_daftar_perusahaan, tabel_pen_pengajuan_spp, tabel_ambil_penyuluhan,tabel_propinsi,tabel_kabupaten_kota WHERE tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = tabel_ambil_penyuluhan.nomor_r_permohonan_penyuluhan AND tabel_daftar_perusahaan.kode_perusahaan = tabel_pen_pengajuan_spp.kode_r_perusahaan and tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi $q_provinsi $q_kabupaten and tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten")->num_rows();
		} else {
			if($this->session->userdata('user_segment')==5){
				$kab = $this->db->query("select * from tabel_propinsi join tabel_kabupaten_kota on tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi where id_urut_kabupaten in (".$this->session->userdata('code').")")->result();
				
				$data['filter_kab'] = "";
				foreach($kab as $r){
					$prov_arr[] = $r->no_kode_propinsi;
					if($r->id_urut_kabupaten==$kabupaten){
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten' selected>$r->no_kabupaten. $r->nm_kabupaten</option>";
					} else {
						$data['filter_kab'] = $data['filter_kab']."<option value='$r->id_urut_kabupaten'>$r->no_kabupaten. $r->nm_kabupaten</option>";
					}
				}
				//print_r(); exit;
				$prov = $this->db->query("select * from tabel_propinsi where no_kode_propinsi in (".implode(",",$prov_arr).")")->result();
			} else {
				$data['filter'] = "<option disabled selected>- Pilih Provinsi -</option>";
				$data['filter_kab'] = "<option disabled selected>- Pilih Provinsi Terlebih Dahulu -</option>";
			}
			
			$data['jumlah_industri_pangan'] = $this->db->query("SELECT * FROM tabel_penyelenggara_penyuluhan, tabel_daftar_perusahaan, tabel_pen_pengajuan_spp, tabel_ambil_penyuluhan WHERE tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = tabel_ambil_penyuluhan.nomor_r_permohonan_penyuluhan AND tabel_daftar_perusahaan.kode_perusahaan = tabel_pen_pengajuan_spp.kode_r_perusahaan")->num_rows();
		}
		
		//download
		if($provinsi!='' or $kabupaten!=''){
			if($provinsi==""){ $data['propinsi'] = 0; } else { $data['propinsi'] = $provinsi; }
			
			$data['kabupaten'] = $kabupaten;
		} else {
			$data['propinsi'] = 0;
			$data['kabupaten'] = 0;
		}
		
		if(count(@$prov)>0){
			$data['data_select'] = @$prov;
		} else {
			$data['data_select'] = $this->db->get('tabel_propinsi')->result();
		}
		$data['tanggal_awal'] = $tanggal_awal;
		$data['tanggal_akhir'] = $tanggal_akhir;
		
		$data['jumlah_peserta_pelatihan'] = $i;
		
		//$this->lib_irtp->display('output_peserta',$data);
		return view_dashboard('irtp/pelaksanaan_pkp/output_penyelenggaraan', $data);
	}

	public function output_laporan_daftar_peserta($nomor_permohonan_penyuluhan){
		$query =  $this->db->query("SELECT * FROM 
		tabel_penyelenggara_penyuluhan, 
		tabel_daftar_perusahaan, 
		tabel_pen_pengajuan_spp, 
		tabel_ambil_penyuluhan,
		tabel_propinsi, tabel_kabupaten_kota WHERE 
		tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = tabel_ambil_penyuluhan.nomor_r_permohonan_penyuluhan and
		tabel_ambil_penyuluhan.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan AND
		tabel_daftar_perusahaan.kode_perusahaan = tabel_pen_pengajuan_spp.kode_r_perusahaan
		and tabel_propinsi.no_kode_propinsi = tabel_kabupaten_kota.no_kode_propinsi and 
		tabel_daftar_perusahaan.id_r_urut_kabupaten=tabel_kabupaten_kota.id_urut_kabupaten and 
		tabel_penyelenggara_penyuluhan.id_r_urut_kabupaten = tabel_kabupaten_kota.id_urut_kabupaten
		and tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = '".$nomor_permohonan_penyuluhan."'
		");
		//print_r($query->result()); exit;
		
		$data['cek_penerbitan'] = $this->db->query("select * from tabel_penyelenggara_penyuluhan 
							join tabel_kabupaten_kota on id_urut_kabupaten = id_r_urut_kabupaten 
							join tabel_propinsi on tabel_kabupaten_kota.no_kode_propinsi = tabel_propinsi.no_kode_propinsi 
							where nomor_permohonan_penyuluhan = '".$nomor_permohonan_penyuluhan."' limit 1")->result_array();

		//if($query->num_rows >= 1){
			$data['query'] = $query->result();
			//return view_dashboard('irtp/pelaksanaan_pkp/print_5', $data);
			$this->load->view('irtp/pelaksanaan_pkp/print_5', $data);
		//}
	}

	public function output_laporan_penyelenggaraan_unduh($nomor_permohonan_penyuluhan){
		/* $query =  $this->db->query("SELECT * FROM 
		tabel_penyelenggara_penyuluhan, 
		tabel_daftar_perusahaan, 
		tabel_pen_pengajuan_spp, 
		tabel_ambil_penyuluhan, 
		tabel_kabupaten_kota, 
		tabel_propinsi WHERE 
		nomor_permohonan = nomor_r_permohonan and 
		tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = tabel_ambil_penyuluhan.nomor_r_permohonan_penyuluhan AND 
		tabel_daftar_perusahaan.kode_perusahaan = tabel_pen_pengajuan_spp.kode_r_perusahaan AND 
		tabel_daftar_perusahaan.id_r_urut_kabupaten = tabel_kabupaten_kota.id_urut_kabupaten AND 
		tabel_penyelenggara_penyuluhan.id_r_urut_kabupaten = tabel_kabupaten_kota.id_urut_kabupaten AND 
		tabel_kabupaten_kota.no_kode_propinsi = tabel_propinsi.no_kode_propinsi AND 
		tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = '".$nomor_permohonan_penyuluhan."' and 
		tabel_ambil_penyuluhan.nomor_r_permohonan = tabel_pen_pengajuan_spp.nomor_permohonan"); */
		
		$query =  $this->db->query("SELECT * FROM 
		tabel_penyelenggara_penyuluhan, 
		tabel_daftar_perusahaan, 
		tabel_pen_pengajuan_spp, 
		tabel_kabupaten_kota, 
		tabel_propinsi WHERE 
		tabel_daftar_perusahaan.kode_perusahaan = tabel_pen_pengajuan_spp.kode_r_perusahaan AND 
		tabel_daftar_perusahaan.id_r_urut_kabupaten = tabel_kabupaten_kota.id_urut_kabupaten AND 
		tabel_penyelenggara_penyuluhan.id_r_urut_kabupaten = tabel_kabupaten_kota.id_urut_kabupaten AND 
		tabel_kabupaten_kota.no_kode_propinsi = tabel_propinsi.no_kode_propinsi AND 
		tabel_penyelenggara_penyuluhan.nomor_permohonan_penyuluhan = '".$nomor_permohonan_penyuluhan."'
		");
		foreach($query->result() as $row){
			$data['jumlah_peserta'] = $this->db->query("select * from tabel_ambil_penyuluhan where nomor_r_permohonan_penyuluhan = '".$row->nomor_permohonan_penyuluhan."'")->num_rows();
		}
		
		$data['cek_penerbitan'] = $this->db->query("select * from tabel_penyelenggara_penyuluhan 
							join tabel_kabupaten_kota on id_urut_kabupaten = id_r_urut_kabupaten 
							join tabel_propinsi on tabel_kabupaten_kota.no_kode_propinsi = tabel_propinsi.no_kode_propinsi 
							where nomor_permohonan_penyuluhan = '".$nomor_permohonan_penyuluhan."' limit 1")->result_array();
		
		//if($query->num_rows >= 1){
			$data['query'] = $query->result();
			//return view_dashboard('irtp/pelaksanaan_pkp/print_4', $data);
			$this->load->view('irtp/pelaksanaan_pkp/print_4', $data);
		//}
	}

	public function input()
	{
		$data['js_materi'] = $this->db->get('tabel_materi_penyuluhan')->result();
		$data['js_materi_utama'] = $this->db->query('SELECT * FROM tabel_materi_penyuluhan WHERE status_materi="utama"')->result();
		$data['js_materi_pendukung'] = $this->db->query('SELECT * FROM tabel_materi_penyuluhan WHERE status_materi="pendukung"')->result();
		
		$data['js_narasumber'] = $this->irtp_model->data_pkp()->result();
		return view_dashboard('irtp/pelaksanaan_pkp/input_pkp', $data);
	}

	function add()
	{
		$config = array(
			array(
				'field' => 'tanggal_pelatihan_awal',
				'label'   => 'Tanggal Pelatihan Awal', 
                'rules'   => 'trim|required|xss_clean'
			),			
			array(
				'field' => 'tanggal_pelatihan_akhir',
				'label'   => 'Tanggal Pelatihan Akhir', 
                'rules'   => 'trim|required|xss_clean'
			),			
		);
		$this->form_validation->set_rules($config);

		if ($this->form_validation->run() == FALSE)
		{
			$data['error'] = $this->session->set_flashdata('error', '<div class="alert alert-danger"><strong>Warning!</strong> '.validation_errors().'</div>');
			
			$data['status'] = $this->session->set_flashdata('<div class="alert alert-warning">Data tidak tersubmit karena terjadi kesalahan. Harap ulangi</div>');
			redirect('pelaksanaan_pkp/input_pkp');
		}
		else
		{
			if($this->irtp_model->add_data_irtp_penyelenggaraan()){
				$data['message'] = $this->session->set_flashdata('error', '<div class="alert alert-info"><strong>Selamat!</strong> Informasi penyuluhan terbaru telah dimasukkan</div>');

				redirect('pelaksanaan_pkp/output_penyelenggaraan');
			} // ambil dari file models/irtp_model.php
		}
	}

}